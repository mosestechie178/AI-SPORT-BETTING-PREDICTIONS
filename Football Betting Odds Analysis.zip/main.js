// Football Betting Prediction Tool - Main Application
// Professional betting analysis platform with ML-powered predictions

class BettingPredictionApp {
    constructor() {
        this.currentPage = window.location.pathname.split('/').pop() || 'index.html';
        this.bankroll = parseFloat(localStorage.getItem('bankroll')) || 1000;
        this.bettingHistory = JSON.parse(localStorage.getItem('bettingHistory')) || [];
        this.predictionCache = new Map();
        this.oddsUpdateInterval = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeAnimations();
        this.loadPageSpecificContent();
        this.startRealTimeUpdates();
    }

    setupEventListeners() {
        // Navigation handling
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-nav]')) {
                this.handleNavigation(e.target.dataset.nav);
            }
            
            if (e.target.matches('[data-bet]')) {
                this.handleBetPlacement(e.target.dataset.bet);
            }
            
            if (e.target.matches('[data-analysis]')) {
                this.showMatchAnalysis(e.target.dataset.analysis);
            }
        });

        // Bankroll management
        document.addEventListener('input', (e) => {
            if (e.target.matches('[data-bankroll-input]')) {
                this.updateBankroll(e.target.value);
            }
            
            if (e.target.matches('[data-risk-slider]')) {
                this.updateRiskLevel(e.target.value);
            }
        });

        // Prediction confidence adjustments
        document.addEventListener('change', (e) => {
            if (e.target.matches('[data-confidence-weight]')) {
                this.recalculatePrediction(e.target.dataset.confidenceWeight, e.target.value);
            }
        });
    }

    initializeAnimations() {
        // Initialize particle background using p5.js
        if (typeof p5 !== 'undefined') {
            this.initParticleBackground();
        }

        // Initialize scroll animations
        this.initScrollAnimations();

        // Initialize typewriter effects
        this.initTypewriterEffects();
    }

    initParticleBackground() {
        new p5((p) => {
            let particles = [];
            const numParticles = 50;

            p.setup = () => {
                const canvas = p.createCanvas(p.windowWidth, p.windowHeight);
                canvas.parent('particle-bg');
                canvas.style('position', 'fixed');
                canvas.style('top', '0');
                canvas.style('left', '0');
                canvas.style('z-index', '-1');

                // Create particles
                for (let i = 0; i < numParticles; i++) {
                    particles.push({
                        x: p.random(p.width),
                        y: p.random(p.height),
                        vx: p.random(-0.5, 0.5),
                        vy: p.random(-0.5, 0.5),
                        size: p.random(2, 4),
                        opacity: p.random(0.3, 0.8),
                        color: p.random(['#10b981', '#3b82f6', '#6366f1'])
                    });
                }
            };

            p.draw = () => {
                p.clear();
                
                particles.forEach(particle => {
                    // Update position
                    particle.x += particle.vx;
                    particle.y += particle.vy;

                    // Wrap around edges
                    if (particle.x < 0) particle.x = p.width;
                    if (particle.x > p.width) particle.x = 0;
                    if (particle.y < 0) particle.y = p.height;
                    if (particle.y > p.height) particle.y = 0;

                    // Draw particle
                    p.fill(particle.color + Math.floor(particle.opacity * 255).toString(16));
                    p.noStroke();
                    p.circle(particle.x, particle.y, particle.size);
                });

                // Draw connections
                particles.forEach((p1, i) => {
                    particles.slice(i + 1).forEach(p2 => {
                        const dist = p.dist(p1.x, p1.y, p2.x, p2.y);
                        if (dist < 100) {
                            p.stroke(255, 255, 255, (1 - dist / 100) * 30);
                            p.strokeWeight(1);
                            p.line(p1.x, p1.y, p2.x, p2.y);
                        }
                    });
                });
            };

            p.windowResized = () => {
                p.resizeCanvas(p.windowWidth, p.windowHeight);
            };
        });
    }

    initScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const element = entry.target;
                    
                    if (typeof anime !== 'undefined') {
                        anime({
                            targets: element,
                            translateY: [20, 0],
                            opacity: [0, 1],
                            duration: 300,
                            easing: 'easeOutQuad',
                            delay: element.dataset.delay || 0
                        });
                    }
                    
                    observer.unobserve(element);
                }
            });
        }, observerOptions);

        document.querySelectorAll('[data-animate]').forEach(el => {
            observer.observe(el);
        });
    }

    initTypewriterEffects() {
        if (typeof Typed !== 'undefined') {
            const typewriterElements = document.querySelectorAll('[data-typewriter]');
            
            typewriterElements.forEach(element => {
                const text = element.dataset.typewriter;
                const typewriter = new Typed(element, {
                    strings: [text],
                    typeSpeed: 50,
                    showCursor: true,
                    cursorChar: '|',
                    onComplete: () => {
                        setTimeout(() => typewriter.destroy(), 2000);
                    }
                });
            });
        }
    }

    loadPageSpecificContent() {
        switch (this.currentPage) {
            case 'index.html':
                this.loadDashboard();
                break;
            case 'analysis.html':
                this.loadAnalysis();
                break;
            case 'bankroll.html':
                this.loadBankroll();
                break;
            case 'about.html':
                this.loadAbout();
                break;
        }
    }

    loadDashboard() {
        this.generateLiveOdds();
        this.updatePredictionHighlights();
        this.updateQuickStats();
    }

    generateLiveOdds() {
        const matches = this.getMockMatches();
        const oddsGrid = document.getElementById('live-odds-grid');
        
        if (!oddsGrid) return;

        oddsGrid.innerHTML = matches.map(match => this.createOddsCard(match)).join('');
        
        // Initialize chart animations
        setTimeout(() => this.animateOddsCards(), 100);
    }

    getMockMatches() {
        const teams = [
            'Manchester United', 'Liverpool', 'Chelsea', 'Arsenal',
            'Real Madrid', 'Barcelona', 'Bayern Munich', 'PSG',
            'Juventus', 'AC Milan', 'Inter Milan', 'Atletico Madrid'
        ];

        return Array.from({ length: 10 }, (_, i) => {
            const homeTeam = teams[Math.floor(Math.random() * teams.length)];
            let awayTeam = teams[Math.floor(Math.random() * teams.length)];
            while (awayTeam === homeTeam) {
                awayTeam = teams[Math.floor(Math.random() * teams.length)];
            }

            return {
                id: i + 1,
                homeTeam,
                awayTeam,
                kickoff: new Date(Date.now() + Math.random() * 86400000 * 3),
                odds: {
                    homeWin: (1.5 + Math.random() * 2).toFixed(2),
                    draw: (3.0 + Math.random() * 2).toFixed(2),
                    awayWin: (1.8 + Math.random() * 2).toFixed(2),
                    over25: (1.7 + Math.random() * 1).toFixed(2),
                    btts: (1.6 + Math.random() * 1).toFixed(2)
                },
                confidence: Math.floor(60 + Math.random() * 35),
                value: (Math.random() * 20 - 10).toFixed(1)
            };
        });
    }

    createOddsCard(match) {
        const valueColor = parseFloat(match.value) > 5 ? 'text-green-400' : 
                          parseFloat(match.value) < -5 ? 'text-red-400' : 'text-gray-400';
        
        return `
            <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-750 transition-all duration-300 transform hover:scale-105 cursor-pointer" 
                 data-match="${match.id}" data-animate="true">
                <div class="flex justify-between items-center mb-3">
                    <div class="text-sm text-gray-400">
                        ${match.kickoff.toLocaleDateString()} ${match.kickoff.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="text-xs px-2 py-1 bg-blue-600 rounded">${match.confidence}%</span>
                        <span class="text-xs px-2 py-1 rounded ${valueColor}">${match.value}%</span>
                    </div>
                </div>
                
                <div class="mb-4">
                    <div class="font-semibold text-white">${match.homeTeam}</div>
                    <div class="text-gray-400 text-center">vs</div>
                    <div class="font-semibold text-white">${match.awayTeam}</div>
                </div>
                
                <div class="grid grid-cols-2 gap-2 text-sm">
                    <div class="bg-gray-700 p-2 rounded text-center">
                        <div class="text-gray-400">1</div>
                        <div class="font-bold text-white">${match.odds.homeWin}</div>
                    </div>
                    <div class="bg-gray-700 p-2 rounded text-center">
                        <div class="text-gray-400">X</div>
                        <div class="font-bold text-white">${match.odds.draw}</div>
                    </div>
                    <div class="bg-gray-700 p-2 rounded text-center">
                        <div class="text-gray-400">2</div>
                        <div class="font-bold text-white">${match.odds.awayWin}</div>
                    </div>
                    <div class="bg-gray-700 p-2 rounded text-center">
                        <div class="text-gray-400">O/U</div>
                        <div class="font-bold text-white">${match.odds.over25}</div>
                    </div>
                </div>
                
                <div class="mt-3 flex justify-between">
                    <button class="px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-sm transition-colors"
                            data-bet="${match.id}">Bet</button>
                    <button class="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-sm transition-colors"
                            data-analysis="${match.id}">Analysis</button>
                </div>
            </div>
        `;
    }

    animateOddsCards() {
        if (typeof anime === 'undefined') return;

        anime({
            targets: '[data-match]',
            translateY: [30, 0],
            opacity: [0, 1],
            duration: 600,
            delay: anime.stagger(100),
            easing: 'easeOutQuad'
        });
    }

    updatePredictionHighlights() {
        const highlights = this.getTopPredictions();
        const container = document.getElementById('prediction-highlights');
        
        if (!container) return;

        container.innerHTML = highlights.map(pred => this.createPredictionCard(pred)).join('');
    }

    getTopPredictions() {
        return [
            {
                match: 'Manchester United vs Liverpool',
                prediction: 'Over 2.5 Goals',
                confidence: 87,
                odds: 1.85,
                stake: '3%',
                reasoning: 'Both teams score high in attacking metrics, recent H2H shows goal-heavy matches'
            },
            {
                match: 'Real Madrid vs Barcelona',
                prediction: 'Real Madrid Win',
                confidence: 72,
                odds: 2.10,
                stake: '2%',
                reasoning: 'Home advantage, superior recent form, key player availability'
            },
            {
                match: 'Bayern Munich vs PSG',
                prediction: 'Both Teams Score',
                confidence: 79,
                odds: 1.65,
                stake: '2.5%',
                reasoning: 'Strong attacking lineups, defensive vulnerabilities in both teams'
            }
        ];
    }

    createPredictionCard(prediction) {
        const confidenceColor = prediction.confidence > 80 ? 'text-green-400' : 
                               prediction.confidence > 65 ? 'text-yellow-400' : 'text-red-400';
        
        return `
            <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-750 transition-all duration-300" 
                 data-animate="true">
                <div class="flex justify-between items-start mb-3">
                    <div class="flex-1">
                        <h3 class="font-semibold text-white text-sm">${prediction.match}</h3>
                        <p class="text-blue-400 font-medium">${prediction.prediction}</p>
                    </div>
                    <div class="text-right">
                        <div class="text-2xl font-bold ${confidenceColor}">${prediction.confidence}%</div>
                        <div class="text-xs text-gray-400">Confidence</div>
                    </div>
                </div>
                
                <div class="flex justify-between items-center mb-3">
                    <div class="text-gray-400">
                        <span class="text-white font-medium">${prediction.odds}</span> odds
                    </div>
                    <div class="text-gray-400">
                        <span class="text-white font-medium">${prediction.stake}</span> stake
                    </div>
                </div>
                
                <div class="text-xs text-gray-500 mb-3">
                    ${prediction.reasoning}
                </div>
                
                <div class="w-full bg-gray-700 rounded-full h-2">
                    <div class="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-1000" 
                         style="width: ${prediction.confidence}%"></div>
                </div>
            </div>
        `;
    }

    updateQuickStats() {
        const stats = this.calculateQuickStats();
        const container = document.getElementById('quick-stats');
        
        if (!container) return;

        container.innerHTML = `
            <div class="grid grid-cols-4 gap-4">
                <div class="text-center">
                    <div class="text-2xl font-bold text-green-400">${stats.todayPredictions}</div>
                    <div class="text-xs text-gray-400">Today's Predictions</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold text-blue-400">${stats.accuracy}%</div>
                    <div class="text-xs text-gray-400">Accuracy</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold text-yellow-400">$${stats.bankroll}</div>
                    <div class="text-xs text-gray-400">Bankroll</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold text-purple-400">${stats.activeOpportunities}</div>
                    <div class="text-xs text-gray-400">Opportunities</div>
                </div>
            </div>
        `;
    }

    calculateQuickStats() {
        return {
            todayPredictions: 15,
            accuracy: 73,
            bankroll: this.bankroll.toFixed(0),
            activeOpportunities: 8
        };
    }

    startRealTimeUpdates() {
        // Simulate real-time odds updates every 30 seconds
        this.oddsUpdateInterval = setInterval(() => {
            this.updateOdds();
        }, 30000);

        // Update predictions every 5 minutes
        setInterval(() => {
            this.updatePredictions();
        }, 300000);
    }

    updateOdds() {
        // Simulate odds fluctuations
        document.querySelectorAll('[data-match]').forEach(card => {
            const oddsElements = card.querySelectorAll('.font-bold.text-white');
            oddsElements.forEach(el => {
                const currentOdds = parseFloat(el.textContent);
                const variation = (Math.random() - 0.5) * 0.1;
                const newOdds = Math.max(1.01, currentOdds + variation);
                el.textContent = newOdds.toFixed(2);
            });
        });
    }

    updatePredictions() {
        // Simulate prediction updates based on new data
        this.updatePredictionHighlights();
    }

    handleNavigation(page) {
        if (page !== this.currentPage) {
            window.location.href = page;
        }
    }

    handleBetPlacement(betId) {
        // Show bet placement modal or redirect to bookmaker
        this.showBetModal(betId);
    }

    showBetModal(betId) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4">
                <h3 class="text-xl font-bold text-white mb-4">Place Bet</h3>
                <p class="text-gray-300 mb-4">This would normally redirect to your chosen bookmaker.</p>
                <div class="flex space-x-4">
                    <button class="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded transition-colors"
                            onclick="this.closest('.fixed').remove()">
                        Continue to Bookmaker
                    </button>
                    <button class="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded transition-colors"
                            onclick="this.closest('.fixed').remove()">
                        Cancel
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    showMatchAnalysis(matchId) {
        // Store selected match and navigate to analysis page
        localStorage.setItem('selectedMatch', matchId);
        window.location.href = 'analysis.html';
    }

    updateBankroll(amount) {
        this.bankroll = parseFloat(amount) || 0;
        localStorage.setItem('bankroll', this.bankroll.toString());
        this.updateQuickStats();
    }

    updateRiskLevel(level) {
        localStorage.setItem('riskLevel', level);
        // Recalculate recommendations based on new risk level
        this.updatePredictions();
    }

    recalculatePrediction(factor, weight) {
        // Update prediction model weights
        const weights = JSON.parse(localStorage.getItem('predictionWeights') || '{}');
        weights[factor] = parseFloat(weight);
        localStorage.setItem('predictionWeights', JSON.stringify(weights));
        
        // Recalculate predictions with new weights
        this.updatePredictions();
    }

    // Cleanup
    destroy() {
        if (this.oddsUpdateInterval) {
            clearInterval(this.oddsUpdateInterval);
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.bettingApp = new BettingPredictionApp();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.bettingApp) {
        window.bettingApp.destroy();
    }
});