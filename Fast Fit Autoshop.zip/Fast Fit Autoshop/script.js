// Mobile menu toggle
const mobileMenu = document.getElementById('mobile-menu');
const navLinks = document.getElementById('nav-links');

mobileMenu.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('#nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('active');
  });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      window.scrollTo({
        top: target.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  });
});

// Contact form submission
const contactForm = document.getElementById('contact-form');
contactForm.addEventListener('submit', function(e) {
  e.preventDefault();

  // Get form values
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const service = document.getElementById('service').value;
  const message = document.getElementById('message').value;

  // Normally send data to server here
  alert(`Thank you, ${name}! Your message has been received. We'll contact you soon.`);

  // Reset the form
  contactForm.reset();
});

// Newsletter form submission
const newsletterForm = document.getElementById('newsletter-form');
newsletterForm.addEventListener('submit', function(e) {
  e.preventDefault();

  // Get email value
  const email = this.querySelector('input[type="email"]').value;

  // Normally send email to server here
  alert(`Thank you for subscribing with email: ${email}`);

  // Reset the form
  this.reset();
});

// Dashboard modal logic

function showDashboard() {
  const modal = document.getElementById('dashboard-modal');
  const inner = document.getElementById('dashboard-inner');

  // Login form HTML
  const loginHtml = `
    <h1 style="color:#0078D4; text-align:center;">Dashboard Login</h1>
    <form id="dashboardLoginForm" style="max-width:400px; margin:auto;">
      <label for="loginEmail">Email</label>
      <input type="email" id="loginEmail" name="email" required />
      
      <label for="loginPassword">Password</label>
      <input type="password" id="loginPassword" name="password" required />
      
      <label for="loginRole">Role</label>
      <select id="loginRole" name="role" required>
        <option value="">Select Role</option>
        <option value="garage">Garage Staff</option>
        <option value="manager">Manager</option>
        <option value="warehouse">Warehouse Staff</option>
      </select>
      
      <button type="submit">Login</button>
    </form>
  `;

  inner.innerHTML = loginHtml;
  modal.classList.add('active');

  // Handle login form submission
  const loginForm = document.getElementById('dashboardLoginForm');
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = loginForm.email.value.trim();
    const password = loginForm.password.value.trim();
    const role = loginForm.role.value;

    if (!email || !password || !role) {
      alert('Please fill in all fields.');
      return;
    }

    // Simulate authentication success (replace with real API call)
    alert(`Logged in as ${role} successfully!`);

    // Load dashboard content for the selected role
    loadDashboardContent(role);
  });
}

function loadDashboardContent(type) {
  const inner = document.getElementById('dashboard-inner');
  let html = '';
  if (type === 'garage') {
    html = `
      <h1 style="color:#0078D4;">Place an Order</h1>
      <form id="orderForm">
        <label>Customer ID: <input type="number" name="customer_id" required></label><br/><br/>
        <label>Garage ID: <input type="number" name="garage_id" required></label><br/><br/>
        <label>Part ID: <input type="number" name="part_id" required></label><br/><br/>
        <label>Quantity: <input type="number" name="quantity" required></label><br/><br/>
        <button type="submit">Submit Order</button>
      </form>
    `;
  } else if (type === 'manager') {
    html = `
      <h1 style="color:#0078D4;">Manager Dashboard</h1>
      <section id="sales">
        <h2>Sales by Garage</h2>
        <table id="salesTable"><thead><tr><th>Garage</th><th>Total Sales</th></tr></thead><tbody></tbody></table>
      </section>
      <section id="stock">
        <h2>Stock Summary</h2>
        <table id="stockTable"><thead><tr><th>Garage</th><th>Part</th><th>Quantity</th></tr></thead><tbody></tbody></table>
      </section>
      <section id="orders">
        <h2>Recent Orders</h2>
        <table id="ordersTable"><thead><tr><th>Order ID</th><th>Customer</th><th>Garage</th><th>Part</th><th>Qty</th><th>Date</th><th>Status</th></tr></thead><tbody></tbody></table>
      </section>
    `;
  } else if (type === 'warehouse') {
    html = `
      <h1 style="color:#0078D4;">Warehouse Dispatch Dashboard</h1>
      <section id="orders">
        <h2>Pending Orders</h2>
        <table id="ordersTable"><thead><tr><th>Order ID</th><th>Garage</th><th>Part</th><th>Qty</th><th>Status</th><th>Action</th></tr></thead><tbody></tbody></table>
      </section>
      <section id="stock">
        <h2>Update Warehouse Stock</h2>
        <form id="stockForm">
          <label>Part ID: <input type="number" name="part_id" required></label><br/><br/>
          <label>New Stock Quantity: <input type="number" name="new_stock" required></label><br/><br/>
          <button type="submit">Update Stock</button>
        </form>
      </section>
    `;
  }
  inner.innerHTML = html;

  // Attach dashboard-specific JS after rendering
  setTimeout(() => {
    if (type === 'garage') {
      const orderForm = document.getElementById('orderForm');
      if (orderForm) {
        orderForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const data = Object.fromEntries(new FormData(e.target));
          // Simulate POST request
          alert(`Order submitted:\nCustomer ID: ${data.customer_id}\nGarage ID: ${data.garage_id}\nPart ID: ${data.part_id}\nQuantity: ${data.quantity}`);
          orderForm.reset();
        });
      }
    } else if (type === 'manager') {
      // Simulate loading data for tables
      function loadData(tableId, rows) {
        const tbody = document.querySelector('#'+tableId+' tbody');
        tbody.innerHTML = rows.map(r => {
          if (tableId === 'salesTable') return `<tr><td>${r.location}</td><td>$${r.total_sales}</td></tr>`;
          if (tableId === 'stockTable') return `<tr><td>${r.location}</td><td>${r.part_name}</td><td>${r.quantity}</td></tr>`;
          if (tableId === 'ordersTable') return `<tr><td>${r.order_id}</td><td>${r.customer}</td><td>${r.location}</td><td>${r.part}</td><td>${r.quantity}</td><td>${r.order_date}</td><td>${r.status}</td></tr>`;
          return '';
        }).join('');
      }
      // Dummy data
      loadData('salesTable', [
        {location: 'Garage A', total_sales: 12000},
        {location: 'Garage B', total_sales: 8500}
      ]);
      loadData('stockTable', [
        {location: 'Garage A', part_name: 'Brake Pads', quantity: 50},
        {location: 'Garage B', part_name: 'Engine Oil', quantity: 100}
      ]);
      loadData('ordersTable', [
        {order_id: 101, customer: 'John Doe', location: 'Garage A', part: 'Brake Pads', quantity: 2, order_date: '2025-01-10', status: 'Completed'},
        {order_id: 102, customer: 'Jane Smith', location: 'Garage B', part: 'Engine Oil', quantity: 5, order_date: '2025-01-12', status: 'Pending'}
      ]);
    } else if (type === 'warehouse') {
      async function loadOrders() {
        // Dummy pending orders data
        const data = [
          {order_id: 201, garage: 'Garage A', part: 'Brake Pads', quantity: 2, status: 'Pending'},
          {order_id: 202, garage: 'Garage B', part: 'Engine Oil', quantity: 5, status: 'Pending'}
        ];
        const tbody = document.querySelector('#ordersTable tbody');
        tbody.innerHTML = data.map(order => `
          <tr>
            <td>${order.order_id}</td>
            <td>${order.garage}</td>
            <td>${order.part}</td>
            <td>${order.quantity}</td>
            <td>${order.status}</td>
            <td><button onclick="dispatchOrder(${order.order_id})">Dispatch</button></td>
          </tr>
        `).join('');
      }
      window.dispatchOrder = function(orderId) {
        alert(`Order ${orderId} dispatched successfully!`);
        loadOrders();
      };
      const stockForm = document.getElementById('stockForm');
      if (stockForm) {
        stockForm.addEventListener('submit', (e) => {
          e.preventDefault();
          const data = Object.fromEntries(new FormData(e.target));
          alert(`Stock updated:\nPart ID: ${data.part_id}\nNew Quantity: ${data.new_stock}`);
          stockForm.reset();
        });
      }
      loadOrders();
    }
  }, 0);
}

function closeDashboard() {
  document.getElementById('dashboard-modal').classList.remove('active');
  document.getElementById('dashboard-inner').innerHTML = '';
}